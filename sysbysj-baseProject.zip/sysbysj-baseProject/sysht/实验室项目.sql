CREATE DATABASE IF NOT EXISTS laboratory default charset utf8 COLLATE utf8_general_ci;
use laboratory;
create table t_class(
	id int(10) primary key auto_increment,
	name varchar(50),
	head_teacher varchar(20),
	major varchar(30),
	description varchar(400)
);
create table t_student(
	id int(10) primary key auto_increment,
	name varchar(50),
	pwd varchar(50),
	gender int(1),
	tel varchar(20),
	stu_no varchar(20),
	cid int(10)
);
create table t_admin(
	id int(10) primary key auto_increment,
	name varchar(50),
	pwd varchar(50),
	tel varchar(20)
);
create table t_teacher(
	id int(10) primary key auto_increment,
	name varchar(50),
	pwd varchar(50),
	job varchar(50),
	gender int(1),
	tel varchar(20),
	entry_date date,
	description varchar(400)
);
create table t_laboratory(
	id int(10) primary key auto_increment,
	name varchar(50),
	capacity int(5),
	description varchar(400)
);
create table t_book_laboratory(
	id int(10) primary key auto_increment,
	lid int(10),
	tid int(10),
	book_date datetime,
	start_date datetime,
	end_date datetime,
	state int(1),
	book_reason varchar(400),
	description varchar(400)
);
create table t_workhome(
	id int(10) primary key auto_increment,
	title varchar(100),
	content varchar(400),
	description varchar(400),
	submit_date datetime,
	tid int(10),
	workhome_date datetime
);
create table t_student_workhome(
	id int(10) primary key auto_increment,
	sid int(10),
	wid int(10),
	attachment varchar(200),
	student_description varchar(400),
	up_date datetime,
	tid int(10),
	score int(3),
	teacher_description varchar(400)
);
create table t_laboratory_health(
	id int(10) primary key auto_increment,
	lid int(10),
	check_date datetime,
	score int(2),
	checker varchar(20),
	description varchar(400)
);
create table t_repair(
	id int(10) primary key auto_increment,
	name varchar(200),
	wrong_description varchar(400),
	description varchar(400),
	reporter varchar(20),
	state int(1),
	submit_time datetime
);
create table t_document(
	id int(10) primary key auto_increment,
	name varchar(200),
	description varchar(400),
	attachment varchar(200),
	submit_time datetime
);
create table t_health(
	id int(10) primary key auto_increment,
	disinfectioner varchar(20),
	health_description varchar(400),
	description varchar(400),
	disinfection_time datetime
);

