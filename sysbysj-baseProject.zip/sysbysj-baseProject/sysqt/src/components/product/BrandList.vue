<template>
  <div>
    <router-link to="/product/addBrand"><el-button>添加</el-button></router-link>
    <el-table
      :data="brandList"
      :stripe="true"
      style="width: 100%">
      <el-table-column
        prop="brandId"
        label="编号">
      </el-table-column>
      <el-table-column
        prop="name"
        label="品牌名">
      </el-table-column>
      <el-table-column
        prop="showStatus"
        label="是否删除">
      </el-table-column>
      <el-table-column
        prop="firstLetter"
        label="首字母">
      </el-table-column>
      <el-table-column
        prop="sort"
        label="排序">
      </el-table-column>
      <el-table-column
        label="logo">
        <template slot-scope="scope">
          <img :src="scope.row.logo" width="200" height="200"/>
        </template>
      </el-table-column>
      <el-table-column
        prop="brandStory"
        label="品牌故事">
      </el-table-column>

      <el-table-column
        label="操作">
        <template slot-scope="scope">
          <router-link to=""><el-button>修改</el-button></router-link>
          <router-link to=""><el-button>删除</el-button></router-link>
        </template>
      </el-table-column>
    </el-table>
    <router-view/>
  </div>
</template>

<script>
    export default {
        name: "BrandList",
      data(){
          return {
            brandList:[]
          }
      },
      created(){
        //发出ajax请求请求后端代码
        this.axios.get("/brand/selectAll").then((resp)=>{
          this.brandList=resp.data;
        });
      }
    }
</script>

<style scoped>

</style>
