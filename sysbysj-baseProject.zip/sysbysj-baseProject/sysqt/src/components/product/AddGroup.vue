<template>
    <div id="app">
      <el-form ref="add-brand" :model="group" label-width="100px">
        <el-form-item label="组名">
          <el-input v-model="group.attrGroupName" ></el-input>
        </el-form-item>
        <el-form-item label="排序">
          <el-input v-model="group.sort" ></el-input>
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="group.descript"  type="textarea" rows="5"></el-input>
        </el-form-item>
        <el-form-item label="组图标">
          <el-input v-model="group.icon"  ></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="saveGroup()">提交</el-button>
        </el-form-item>
      </el-form>
    </div>
</template>

<script>
    export default {
      data(){
        return {
          group:{}
        }
      },
      methods:{
        saveGroup(){
          this.group.categoryId=this.$route.query.cateId;
          //发出ajax请求
          this.axios.post("/attrGroup/saveGroup",this.group).then((resp)=>{
            this.$message.success("添加分组成功！");
            this.$router.push({path:"/product/attrGroup",query:{cateId:this.group.categoryId}});
          })
        }
      }
    }
</script>


<style scoped>

</style>
