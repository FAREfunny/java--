<template>
    <div id="app">
      <el-form ref="add-brand" :model="spu" label-width="100px">
        <el-form-item :label="item.attrName"
                      v-for="(item,index) in spuAttrList" :key="index">
          <el-input v-model="attrValue[item.attrId]"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="saveSpuAttr()">提交</el-button>
        </el-form-item>
      </el-form>
    </div>
</template>

<script>
    export default {
      data(){
        return {
          spuAttrList:[],
          spu:{},
          attrValue:{}
        }
      },
      methods:{
        saveSpuAttr(){
          //{"12098":“联通”，“12099”：“led”....}
          //console.log(this.attrValue);
          //想办法把attrValue对象给转换为list集合[{attr_id:"12409",attr_value:"联通"}]
          let attrValueList=[];
          for(let attr in this.attrValue){
            let attr_Value={attr_id:attr,attr_value:this.attrValue[attr]};
            attrValueList.push(attr_Value);
          }
          console.log(attrValueList)
        }
      },
      created(){
        this.axios.get("/attr/selectCommonAttrByCateId/"+this.$route.query.cateId).then((resp)=>{
          this.spuAttrList=resp.data;
        });
      }
    }
</script>


<style scoped>

</style>
