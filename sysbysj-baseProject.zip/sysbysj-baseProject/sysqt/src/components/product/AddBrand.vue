<template>
    <div id="app">
      <el-form ref="add-brand" :model="brand" label-width="100px">
        <el-form-item label="品牌名">
          <el-input v-model="brand.name" placeholder="请输入品牌名"></el-input>
        </el-form-item>
        <el-form-item label="品牌首字母">
          <el-input v-model="brand.firstLetter" placeholder="请输入品牌首字母"></el-input>
        </el-form-item>
        <el-form-item label="排序">
          <el-input v-model="brand.sort"  placeholder="请输入排序数值"></el-input>
        </el-form-item>
        <el-form-item label="显示状态">
          <el-switch v-model="brand.showStatus"
                     :active-value="1"
                     :inactive-value="0"
                     active-text="显示"
                     inactive-text="不显示"
          ></el-switch>
        </el-form-item>
        <el-form-item label="图标">
          <el-upload
            class="upload-demo"
            action="http://localhost:8989/brand/uploadPic"
            :limit="1"
            :on-exceed="handleOnExceed"
            name="brandPic"
            accept=".png,.jpg"
            :multiple="false"
            :on-success="handleOnSuccess"
          >
            <el-button size="small" type="primary">点击上传</el-button>
            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
          </el-upload>

        </el-form-item>
        <el-form-item label="品牌描述">
          <el-input v-model="brand.brandStory" placeholder="请输入品牌描述"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="saveBrand()">提交</el-button>
        </el-form-item>
      </el-form>
    </div>
</template>

<script>
    export default {
      data(){
        return {
          brand:{}
        }
      },
      methods:{
        handleOnExceed(){
          console.log("文件个数超出限制");
        },
        handleOnSuccess(resp){
          //文件上传成功之后要把文件上传到哪传给brand对象
          this.brand.logo=resp;
        },
        saveBrand(){
          //发出ajax请求
          this.axios.post("/brand/saveBrand",this.brand).then((resp)=>{
            this.$router.push("/product/brand");
          })
        }
      }
    }
</script>


<style scoped>

</style>
