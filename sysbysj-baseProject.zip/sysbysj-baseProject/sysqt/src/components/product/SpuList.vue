<template>
  <div>
    <el-table
      :data="spuList"
      :stripe="true"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="编号">
      </el-table-column>
      <el-table-column
        prop="spuName"
        label="spu名">
      </el-table-column>
      <el-table-column
        prop="spuDescription"
        label="描述">
      </el-table-column>

      <el-table-column
        prop="createTime"
        label="创建时间">
      </el-table-column>

      <el-table-column
        label="操作">
        <template slot-scope="scope">
          <router-link to=""><el-button>修改</el-button></router-link>
          <router-link to=""><el-button>删除</el-button></router-link>
          <router-link :to="{path:'/product/addSpuAttr',query:{cateId:scope.row.categoryId,spuId:scope.row.id}}"><el-button>添加属性值</el-button></router-link>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
    export default {
        name: "SpuList",
      data(){
          return {
            spuList:[]
          }
      },
      created(){
        this.axios.get("/spuInfo/selectAll").then((resp)=>{
          this.spuList=resp.data;
        });
      },
      methods:{

      }
    }
</script>

<style scoped>

</style>
