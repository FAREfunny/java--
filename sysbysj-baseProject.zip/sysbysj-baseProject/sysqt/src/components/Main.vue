<template>
  <div>
    <h1>欢迎实验室管理系统</h1>
    <router-view></router-view>
  </div>

</template>

<script>
export default {
  name: "Main"
}
</script>

<style scoped>

</style>
