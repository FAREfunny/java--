<template>
  <div>
    <el-table
      :data="roleList"
      :stripe="true"
      style="width: 100%">
      <el-table-column
        prop="roleId"
        label="编号">
      </el-table-column>
      <el-table-column
        prop="roleName"
        label="角色名">
      </el-table-column>

      <el-table-column
        label="操作">
        <template slot-scope="scope">
          <router-link to=""><el-button>修改</el-button></router-link>
          <router-link to=""><el-button>删除</el-button></router-link>
          <router-link :to="{path:'/menu/menuTree',query:{roleId:scope.row.roleId}}"><el-button>授权</el-button></router-link>
        </template>
      </el-table-column>
    </el-table>
    <router-view/>
  </div>
</template>

<script>
    export default {
        name: "RoleList",
      data(){
          return {
            roleList:[]
          }
      },
      created(){
        //发出ajax请求请求后端代码
        this.axios.get("/role/selectAll").then((resp)=>{
          this.roleList=resp.data;
        });
      }
    }
</script>

<style scoped>

</style>
