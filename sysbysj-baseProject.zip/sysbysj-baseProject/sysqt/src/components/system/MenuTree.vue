<template>
  <div>
    <el-tree
      :data="menuTree" :props="defaultProp"
      show-checkbox
      ref="tree"
      node-key="menuId"
      :default-checked-keys="roleMenuIds"
    ></el-tree>
    <el-button @click="getCheckedKeys">保存权限</el-button>
  </div>
</template>

<script>
    export default {
        name: "",
      data(){
          return {
            menuTree:[],
            defaultProp:{
              label:"name",
              children:"children"
            },
            checkedMenuIds:[],
            roleMenuDto:{},
            roleMenuIds:[]
          }
      },
      methods:{
        getCheckedKeys() {
          this.roleMenuDto.roleId=this.$route.query.roleId;
          this.checkedMenuIds=this.checkedMenuIds.concat(this.$refs.tree.getCheckedKeys()).concat(this.$refs.tree.getHalfCheckedKeys());
          this.roleMenuDto.menuIds=this.checkedMenuIds;
          //发出ajax请求
          this.axios.post("/roleResource/addRoleResource",this.roleMenuDto).then((resp)=>{
            this.$message.success("角色赋权成功！");
            this.$router.push("/role/selectAll");
          })
        }
      },
      created(){
          //生成整个权限树
          this.axios.get("/menu/selectMenuTree").then((resp)=>{
            this.menuTree=resp.data;
            //给树的默认权限赋值
            this.axios.get("/roleResource/selectMenusByRoleId/"+this.$route.query.roleId).then((resp)=>{
              this.roleMenuIds=resp.data.map((roleMenu)=>{return roleMenu.resourceId});
            });

          });
      }
    }
</script>

<style scoped>

</style>
