<template>
  <div>
    <el-form :inline="true" class="demo-form-inline">
      <el-form-item label="姓名">
        <el-input v-model="name"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="">搜索</el-button>
        <router-link to="/admin/addAdmin"><el-button>添加</el-button></router-link>
      </el-form-item>
    </el-form>
    <el-table
      :data="pi.records"
      :stripe="true"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="编号">
      </el-table-column>
      <el-table-column
        prop="username"
        label="用户名">
      </el-table-column>
      <el-table-column
        prop="password"
        label="密码">
      </el-table-column>

      <el-table-column
        prop="status"
        label="状态">
      </el-table-column>

      <el-table-column
        label="操作">
        <template slot-scope="scope">
          <router-link to=""><el-button>修改</el-button></router-link>
          <router-link to=""><el-button>删除</el-button></router-link>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      layout="sizes, prev, pager, next, jumper, ->, total"
      :total="pi.total"
      :page-size.sync="pi.pageSize"
      :page-sizes="[2,5,10,50]"
      :current-page.sync="pi.current"
      :pager-count="9"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      background>
    </el-pagination>
    <router-view/>
  </div>
</template>

<script>
    export default {
        name: "AdminList",
      data(){
          return {
            pi:{},
            name:""
          }
      },
      created(){
        //发出ajax请求请求后端代码
        this.selectByPage(1,5,"");
      },
      methods:{
        handleSizeChange(size){
          //再次调用ajax到后台取数据
          this.selectByPage(this.pi.current,size,this.name);
        },
        handleCurrentChange(page){
          this.selectByPage(page,this.pi.size,this.name);
        },
        selectByPage(pageNum,pageSize,name){
          this.axios.get("/admin/selectAllAdminByPage", {
              params:{
                pageNo:pageNum,
                pageSize:pageSize,
                name:name
              }
            }).then((resp)=>{
            this.pi=resp.data;
          });
        }
      }
    }
</script>

<style scoped>

</style>
