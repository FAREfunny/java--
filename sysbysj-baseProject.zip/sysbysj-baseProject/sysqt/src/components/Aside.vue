<template>
  <el-menu  class="el-menu-demo" align="left"
    background-color="#545c64"
            text-color="#fff"
            active-text-color="#409eff"
            router
            :unique-opened="true"
  >
    <el-submenu index="">
      <template slot="title">
        <span>模块名</span>
      </template>
      <el-menu-item index="跳转地址">链接名</el-menu-item>
      <el-menu-item index="跳转地址">链接名2</el-menu-item>
    </el-submenu>

  </el-menu>
</template>

<script>
export default {
  name: "Aside",
  data(){
    return {
    }
  }
}
</script>

<style scoped>

</style>
