<template>
  <div id="app">
    <el-container style="height: 100vh">
      <el-header>
        <el-row style="margin-top:10px">
          <el-col :span="20">
            <span>百知商城后台系统</span>
          </el-col>
          <el-col :span="4">
            <el-dropdown trigger="click">
              <el-avatar :src="require('../assets/5.jpg')"></el-avatar>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>设置</el-dropdown-item>
                <el-dropdown-item disabled>个人中心</el-dropdown-item>
                <el-dropdown-item dinpmvided>退出</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </el-col>
        </el-row>
      </el-header>
      <el-container>
      <el-aside>
        <mall-aside></mall-aside>
      </el-aside>
        <el-main>
          <mall-main></mall-main>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>

import MallAside from "./Aside";
import MallMain from "./Main";

export default {
  name: 'Manager',
  components: {MallAside,MallMain},
}
</script>

<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;

    color: #2c3e50;

  }
  .el-header{
    background-color: #23262E;
    height: 100px;
    font-size: 14px;
  }
  .el-header span{
    margin-left:20px;
    color: #038777;
    font-size: 30px;
  }

  .el-aside{
    background-color: #545c64;
  }

  .el-main{
    background-color: #F5F7FA;
  }
</style>
