import Vue from 'vue'
import Router from 'vue-router'
import Login from "@/components/Login";
import Manager from "@/components/Manager";
import AdminList from "@/components/system/AdminList";
import addAdmin from "@/components/system/addAdmin";
import RoleList from "@/components/system/RoleList";
import MenuTree from "@/components/system/MenuTree";
import AttrGroupList from "@/components/product/AttrGroupList";
import BrandList from "@/components/product/BrandList";
import AddBrand from "@/components/product/AddBrand";
import AddGroup from "@/components/product/AddGroup";
import SpuList from "@/components/product/SpuList";
import AddCommonAttr from "@/components/product/AddCommonAttr";

Vue.use(Router)

export default new Router({
  routes: [
    {path: "/", component: Login},
    {
      path: "/manager", component: Manager,
      children:[
        {path: "/admin/selectAllAdminByPage", component: AdminList},
        {path: "/admin/addAdmin", component: addAdmin},
        {path: "/role/selectAll", component: RoleList},
        {path: "/menu/menuTree", component: MenuTree},
        {path:"/product/attrGroup",component: AttrGroupList},
        {path:"/product/brand",component: BrandList},
        {path:"/product/addBrand",component: AddBrand},
        {path:"/product/addGroup",component: AddGroup},
        {path:"/product/spu",component: SpuList},
        {path:"/product/addSpuAttr",component: AddCommonAttr}
      ]
    }
  ]
})
